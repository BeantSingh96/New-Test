package com.example.sonaproject.imagePicker.picker

import android.content.Context
import android.content.Intent
import com.example.sonaproject.imagePicker.BOTH
import com.example.sonaproject.imagePicker.CAMERA
import com.example.sonaproject.imagePicker.GALLERY
import com.example.sonaproject.imagePicker.ResultImage
import com.example.sonaproject.imagePicker.SELECTION_TYPE
import com.example.sonaproject.imagePicker.WANT_COMPRESSION
import com.example.sonaproject.imagePicker.WANT_CROP
import com.example.sonaproject.imagePicker.activities.ImagePickerMainActivity

open class CMImagePicker(
    private val activity: Context,
    private var resultImageCallback: ResultImage

) {
    private var crop: Boolean = false
    private var cameraOnly: Boolean = false
    private var galleryOnly: Boolean = false
    private var compress: Boolean = false


    fun allowCrop(crop: Boolean): CMImagePicker {
        this.crop = crop
        return this
    }

    fun allowCameraOnly(cameraOnly: Boolean): CMImagePicker {
        this.cameraOnly = cameraOnly
        return this
    }

    fun allowGalleryOnly(galleryOnly: Boolean): CMImagePicker {
        this.galleryOnly = galleryOnly
        return this
    }

    fun allowCompress(compress: Boolean): CMImagePicker {
        this.compress = compress
        return this
    }

    fun start() {
        val selection = if (cameraOnly && !galleryOnly) {
            CAMERA
        } else if (galleryOnly && !cameraOnly) {
            GALLERY
        } else {
            BOTH
        }

        resultImageCallback.result.launch(
            Intent(activity, ImagePickerMainActivity::class.java).apply {
                putExtra(WANT_CROP, crop)
                putExtra(SELECTION_TYPE, selection)
                putExtra(WANT_COMPRESSION, compress)
            }
        )
    }


}

